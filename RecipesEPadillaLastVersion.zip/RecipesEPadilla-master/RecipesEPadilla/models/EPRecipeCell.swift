//
//  RecipeCell.swift
//  RecipesEPadilla
//
//  Created by Esteban Padilla on 11/23/16.
//  Copyright © 2016 Esteban Padilla. All rights reserved.
//

import Foundation
import UIKit

class EPRecipeCell: UITableViewCell {
  
    @IBOutlet weak var title: UILabel!
    @IBOutlet weak var subTitle: UILabel!

}
